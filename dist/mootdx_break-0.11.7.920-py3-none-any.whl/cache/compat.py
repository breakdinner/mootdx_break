try:
    from typing import ParamSpec, TypeAlias
except (ImportError, ModuleNotFoundError):
    from typing_extensions import ParamSpec, TypeAlias
