from .file import file_cache
from .timed import lru_cache
from .timer import timeit
