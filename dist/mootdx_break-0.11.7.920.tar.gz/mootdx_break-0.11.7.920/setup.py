from setuptools import setup, find_packages
setup(
    name="mootdx_break",
    version="0.11.7.920",
    packages=find_packages(),
    python_requires=">=3.8",
)
